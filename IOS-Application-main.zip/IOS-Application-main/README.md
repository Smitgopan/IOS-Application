# IOS-Application
![Screenshot 2024-03-30 at 1 53 59 PM](https://github.com/rohit0223/ios-project/assets/126228916/636e4ea1-e6bf-4361-a674-db4f59377c0a)
![Screenshot 2024-03-30 at 1 54 27 PM](https://github.com/rohit0223/ios-project/assets/126228916/669f6835-82f9-4493-86c0-4dada2ba79ff)
![Screenshot 2024-03-30 at 1 54 14 PM](https://github.com/rohit0223/ios-project/assets/126228916/7290f75d-adea-4f5c-85ed-0eeddd834913)
![Screenshot 2024-03-30 at 1 55 20 PM](https://github.com/rohit0223/ios-project/assets/126228916/255be296-f57d-4b2f-8200-834e929bf932)
